CREATE TABLE `appointments` (
	`id` text PRIMARY KEY NOT NULL,
	`date` text NOT NULL,
	`start` integer NOT NULL,
	`end` integer NOT NULL,
	`status` text NOT NULL,
	`data` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `guards` (
	`key` integer PRIMARY KEY NOT NULL
);
--> statement-breakpoint
CREATE TABLE `locks` (
	`resource` text NOT NULL,
	`date` text NOT NULL,
	`minute` integer NOT NULL,
	`owner` text NOT NULL,
	PRIMARY KEY(`resource`, `date`, `minute`)
);
--> statement-breakpoint
CREATE TABLE `objects` (
	`kind` text NOT NULL,
	`id` text NOT NULL,
	`data` text NOT NULL,
	PRIMARY KEY(`kind`, `id`)
);
--> statement-breakpoint
CREATE TABLE `revision` (
	`id` integer PRIMARY KEY NOT NULL,
	`value` integer NOT NULL
);
