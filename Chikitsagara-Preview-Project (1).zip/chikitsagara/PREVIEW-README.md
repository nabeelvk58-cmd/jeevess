# Chikitsagara — preview website

This is an unpublished preview. No production database or existing site was changed.

## Run on your computer

Requires Node.js 22.13+ and pnpm 11.25.0 (package manager).

1. Extract this archive.
2. Open a terminal in the extracted folder and run `pnpm install --frozen-lockfile`.
3. Run `node scripts/setup-preview.mjs` once. It builds the app, initializes an isolated local SQLite/D1 database and creates sample resources.
4. Run `npm run dev`. Open the local URL printed by the server.
5. Guest website is `/`. Staff dashboard is `/desk`.
6. The generated preview staff access code is in the local `.dev.vars` file, beside `PREVIEW_DESK_KEY`. Enter it into the desk login form. Do not share it publicly.

The setup script does not publish anything. Bookings are kept centrally in this running preview server’s local database, never browser localStorage. Multiple devices must reach the same server to share availability. The packaged static design review is not a booking server.

## What to review

- 25 official menu entries, search/category filtering and individual treatment details.
- Guest date, available time, guest and room details, summary and request confirmation.
- Desk schedule, week/calendar, treatment/status/resource filters, manual appointments.
- Status changes, assignment, cancellation, rescheduling and blocking resources or entire days.
- Therapists, treatment rooms, eligibility, work hours and unavailable dates.
- Treatment details, images, duration, price, required resources and booking windows.
- Opening hours, breaks, special dates, notice, advance window, slot interval, buffers and cancellation restrictions.

## Preview assumptions to replace before launch

The sample 09:00–17:00 hours, 13:00–14:00 break, 15-minute buffer, six sample therapists and three sample rooms are for testing only. They are editable and are not claimed to be Jeevess’s actual operations. One therapist and the generic `therapy` room type are provisional for menu entries without staffing/room specifications; have your Ayurveda team configure them. Explicit two- and three-therapist menu entries are preserved.

Avagaha Swedam remains 30–45 minutes. Panchakarma, Kalari Training, Yoga & Pranayama and Doctor’s Consultation retain “Duration varies”. Online reservation is disabled until staff set a booking duration; no duration or unlisted price has been invented. Three unpriced services display an enquiry label. All listed prices are preserved. Group totals multiply the listed rate per guest as a preview assumption; confirm your rate policy before launch.

Descriptions explain the general experience with cautious wellness language. The Ayurveda team should approve centre-specific techniques and preparations. Contact details remain placeholders because no numbers were supplied. No WhatsApp or email notifications are sent; staff receive requests in the dashboard.

Photographs are reference images, not photographs of Jeevess. `public/images/sources.json` records sources and rights notes. Kerala Tourism’s gallery labels the treatment photographs royalty-free, but its general reuse text requests permission; replace with approved centre photographs or resolve this before publishing. The Wayanad forest photograph uses the Unsplash free licence. Each card has an image, with a small, consistent set reused across the menu.

## Authentication and privacy

Guest routes expose the menu and availability, not the staff booking list. Staff APIs check authorization server-side. Production is configured to use ChatGPT sign-in with the explicit `STAFF_EMAILS` allowlist. No production staff members have been authorized. The generated preview access code is solely for local testing and must be absent from production.

## Reservation integrity

D1 atomic batches insert the appointment and all resource-minute locks together. The `(resource, date, minute)` primary key rejects overlapping reservations, including buffers. A revision guard rejects stale configuration/booking snapshots. Initialize `guards` with key 1 and `revision` with id 1 during environment setup; the local setup script does this. Rescheduling releases old locks and reserves new locks in the same batch. Staff blocks use the same lock mechanism. A conflict rolls back the whole batch.

One room and the required number of qualified therapists are allocated per guest. The backend validates dates, working hours, breaks, leave, resource types, therapist eligibility, treatment duration, buffer, notice and advance limits. Pending requests reserve resources until staff changes or cancels them. Completed appointments retain historical locks. For fewer cancellation restrictions, staff can edit policy; cancellation is not exposed to anonymous guests.

## Validation performed

- Application builds successfully; TypeScript passes.
- Browser checked: home, treatment details, availability, booking summary, successful request and protected desk entry.
- Real booking engine with an isolated SQLite adapter: simultaneous conflicts, multi-therapist exhaustion, overlap and buffer protection, cancellation release, atomic rescheduling, blocks, variable-duration safeguards and 25-entry catalog all passed.
- Full authenticated staff UI and real-device mobile checks still require review. Production identity, cross-device networking and deployment are not configured or tested.

## Code map

- `lib/treatments.ts`: authoritative menu transcription and descriptions.
- `lib/engine.ts`: resource-aware reservation and availability logic.
- `db/schema.ts`, `drizzle/`: database schema and migrations.
- `app/guest.tsx`, `app/booking.tsx`: guest guide and appointment flow.
- `app/desk/staff.tsx`: staff calendar and management.
- `app/api/public`, `app/api/staff`: public and protected APIs.
- `scripts/test-booking.mjs`: meaningful reservation-integrity checks; run `node scripts/test-booking.mjs` after preview setup.

No deployment is authorized by this archive. Approve design, operational settings and access arrangements before any future publishing step.

## Latest visual update
Original green-and-cream layout and hero retained. Uploaded Jeevess logo in header. Call +91 92880 04402, extension 101; WhatsApp uses the same number. Each treatment has a distinct image. Authentic uploaded photos are used for matching therapies, with clearly labelled illustrative preparation/settings for others. Unmatched eye/spinal treatment photos are not assigned to unrelated menu items.
