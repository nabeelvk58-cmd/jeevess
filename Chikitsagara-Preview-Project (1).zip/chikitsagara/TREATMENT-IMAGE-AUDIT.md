# Treatment image audit

| Treatment | Image | Type |
| --- | --- | --- |
| Abhyangam – Sarvangam with Steam | /images/jeevess-oil.jpg | Uploaded Jeevess photo |
| Abhyangam – Ekangam | /images/generated-oils.jpg | Generated illustrative preparation / setting |
| Kalari Uzhichil – with 3 Therapists | /images/generated-room.jpg | Generated illustrative preparation / setting |
| Kalari Uzhichil – with 2 Therapists | /images/unique-kalari-two.jpg | Generated illustrative preparation / setting |
| Siro Abhyangam | /images/generated-scalp.jpg | Generated illustrative preparation / setting |
| Pada Abhyangam | /images/jeevess-foot.jpg | Uploaded Jeevess photo |
| Padaghata (Chavitti Uzhichil) – with Two Therapists | /images/generated-kalari.jpg | Generated illustrative preparation / setting |
| Padaghata – with One Therapist | /images/unique-padaghata.jpg | Generated illustrative preparation / setting |
| Mukhalepa | /images/generated-facial.jpg | Generated illustrative preparation / setting |
| Sirodhara | /images/jeevess-sirodhara.jpg | Uploaded Jeevess photo |
| Steam Bath – Full Body | /images/generated-steam.jpg | Generated illustrative preparation / setting |
| Steam Bath Local (Nadi Swedam) | /images/generated-local-steam.jpg | Generated illustrative preparation / setting |
| Kesha Sechanam | /images/unique-hair-rinse.jpg | Generated illustrative preparation / setting |
| Mud Pack with Sunbath | /images/generated-mud.jpg | Generated illustrative preparation / setting |
| Churnapinda Swedam | /images/generated-powders.jpg | Generated illustrative preparation / setting |
| Patrapinda Swedam | /images/generated-leaves.jpg | Generated illustrative preparation / setting |
| Jambeerapinda Swedam | /images/generated-citrus.jpg | Generated illustrative preparation / setting |
| Shashtikasali Swedam (Njavaratheppu) | /images/generated-rice.jpg | Generated illustrative preparation / setting |
| Kayasekam (Pizhichil) | /images/unique-pizhichil.jpg | Generated illustrative preparation / setting |
| Utsadanam | /images/unique-utsadanam.jpg | Generated illustrative preparation / setting |
| Avagaha Swedam | /images/generated-bath.jpg | Generated illustrative preparation / setting |
| Panchakarma | /images/unique-panchakarma.jpg | Generated illustrative preparation / setting |
| Kalari Training | /images/unique-kalari-training.jpg | Generated illustrative preparation / setting |
| Yoga & Pranayama | /images/generated-yoga.jpg | Generated illustrative preparation / setting |
| Doctor’s Consultation | /images/generated-consultation.jpg | Generated illustrative preparation / setting |

Each of the 25 cards has a distinct image path. Eye-care and spinal preparation uploads are not assigned to the menu because no matching treatment is listed. Generated settings are illustrative and not represented as actual Jeevess facilities.
