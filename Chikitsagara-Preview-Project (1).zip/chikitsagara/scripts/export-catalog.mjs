import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import ts from 'typescript';
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'chikitsagara-catalog-'));
for(const name of ['photography','treatments']){const source=fs.readFileSync(`lib/${name}.ts`,'utf8').replace("'./photography'","'./photography.mjs'");fs.writeFileSync(path.join(dir,name+'.mjs'),ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText)}
const {initialTreatments}=await import(path.join(dir,'treatments.mjs'));
fs.writeFileSync(process.argv[2]||'treatments.json',JSON.stringify(initialTreatments));
fs.rmSync(dir,{recursive:true,force:true});
