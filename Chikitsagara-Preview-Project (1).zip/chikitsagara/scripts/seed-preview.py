import json,secrets
from pathlib import Path
rows=[]
def add(kind,obj):
 data=json.dumps(obj).replace("'","''");rows.append(f"INSERT OR IGNORE INTO objects(kind,id,data) VALUES('{kind}','{obj['id']}','{data}');")
for i in range(1,7):add('therapist',dict(id=f'demo-{i}',name=f'Sample Therapist {i}',active=True,opening='09:00',closing='17:00',treatments=list(range(1,26)),leave=[]))
for i in range(1,4):add('room',dict(id=f'demo-{i}',name=f'Sample Room A{i}',active=True,opening='09:00',closing='17:00',type='therapy',leave=[]))
rows+=['INSERT OR IGNORE INTO guards(key) VALUES(1);','INSERT OR IGNORE INTO revision(id,value) VALUES(1,0);']
Path('preview-seed.sql').write_text('\n'.join(rows))
if not Path('.dev.vars').exists():Path('.dev.vars').write_text('PREVIEW_DESK_KEY="'+secrets.token_urlsafe(18)+'"\nSTAFF_EMAILS=""\n')
