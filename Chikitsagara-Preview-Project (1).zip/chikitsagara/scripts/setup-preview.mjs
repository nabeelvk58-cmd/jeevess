import {readFileSync,writeFileSync,existsSync,readdirSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {randomBytes} from 'node:crypto';
const run=(args)=>{const r=spawnSync(process.execPath,args,{stdio:'inherit'});if(r.status!==0)process.exit(r.status||1)};
if(!existsSync('.dev.vars'))writeFileSync('.dev.vars','PREVIEW_DESK_KEY="'+randomBytes(18).toString('base64url')+'"\nSTAFF_EMAILS=""\n');
run(['scripts/run-framework.mjs','build']);
const base=['--import','./scripts/sites-env.mjs','./node_modules/wrangler/bin/wrangler.js','d1','execute','DB','--local','--config','dist/server/wrangler.json','--persist-to','.wrangler/state'];
if(!existsSync('.preview-initialized')){for(const file of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())run([...base,'--file','drizzle/'+file]);writeFileSync('.preview-initialized','Local schema applied.\n')}
const rows=[];const add=(kind,obj)=>rows.push(`INSERT OR IGNORE INTO objects(kind,id,data) VALUES('${kind}','${obj.id}','${JSON.stringify(obj).replaceAll("'","''")}');`);
for(let i=1;i<=6;i++)add('therapist',{id:`demo-${i}`,name:`Sample Therapist ${i}`,active:true,opening:'09:00',closing:'17:00',treatments:Array.from({length:25},(_,i)=>i+1),leave:[]});
for(let i=1;i<=3;i++)add('room',{id:`demo-${i}`,name:`Sample Room A${i}`,active:true,opening:'09:00',closing:'17:00',type:'therapy',leave:[]});
rows.push('INSERT OR IGNORE INTO guards(key) VALUES(1);','INSERT OR IGNORE INTO revision(id,value) VALUES(1,0);');
writeFileSync('preview-seed.sql',rows.join('\n'));run([...base,'--file','preview-seed.sql']);
console.log('Preview ready. Run npm run dev. Open /desk for staff access. The preview access code is stored in your local .dev.vars file. No remote database was contacted.');
