import {isStaff} from '@/lib/staff-auth';
import Desk from './staff';
import {env} from 'cloudflare:workers';
export const dynamic='force-dynamic';
export default async function Page(){if(await isStaff())return <Desk/>;return <main className="signin"><p className="eyebrow">CHIKITSAGARA · AYURVEDA DESK</p><h1>Staff access</h1><p>This area is reserved for authorized Ayurveda staff.</p>{(env as any).PREVIEW_DESK_KEY?<form action="/api/staff/login" method="post"><label className="field">Preview access code<input name="key" type="password" required autoComplete="current-password"/></label><button className="button" style={{marginTop:20}}>Open Preview Desk</button></form>:<a className="button" href="/signin-with-chatgpt?return_to=/desk" target="_top">Sign in with ChatGPT</a>}</main>}
