import {NextRequest,NextResponse} from 'next/server';
import {catalog,slots,reserve} from '@/lib/engine';
export const dynamic='force-dynamic';
const json=(d:any,status=200)=>NextResponse.json(d,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(r:NextRequest){try{const p=r.nextUrl.searchParams;if(p.has('date'))return json({slots:await slots(Number(p.get('treatment')),p.get('date')!,Number(p.get('guests')||1))});return json({treatments:(await catalog()).filter(x=>x.active)})}catch{return json({error:'Availability is temporarily unavailable. Please contact the Ayurveda team.'},503)}}
export async function POST(r:NextRequest){try{if(r.headers.get('origin')&&r.headers.get('origin')!==r.nextUrl.origin)return json({error:'Invalid origin'},403);const booking=await reserve(await r.json());const {resources,contact,note,source,...confirmation}=booking;return json({booking:confirmation})}catch(e:any){return json({error:e.message},409)}}
