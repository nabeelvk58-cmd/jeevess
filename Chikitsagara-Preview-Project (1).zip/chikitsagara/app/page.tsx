import Guest from './guest';
export default function Page(){return <Guest/>}
