# Treatment imagery

Existing generated preparation photos and prompts: public/images/generated-provenance.json. New unique image prompts: public/images/unique-provenance.json. Generated using the built-in image-generation tool. All generated treatment images are labelled illustrative preparation / setting; they are not photographs of actual Jeevess facilities.

Full assignment audit: TREATMENT-IMAGE-AUDIT.md. The original hero remains unchanged. The uploaded logo is copied without modification to public/images/jeevess-logo.png and framed responsively with CSS.
