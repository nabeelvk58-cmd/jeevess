import {env} from 'cloudflare:workers';
import {initialTreatments,Treatment} from './treatments';
export const db=()=>{const d=(env as any).DB;if(!d)throw Error('Preview database unavailable');return d as D1Database};
export const defaults={opening:'09:00',closing:'17:00',breakStart:'13:00',breakEnd:'14:00',notice:60,advance:30,interval:30,buffer:15,maxBookings:50,cancellationHours:2,days:[0,1,2,3,4,5,6],specialDates:{},instant:false,preview:true};
export const mins=(s:string)=>{if(!/^\d{2}:\d{2}$/.test(s))throw Error('Invalid time');const [h,m]=s.split(':').map(Number);if(h>23||m>59)throw Error('Invalid time');return h*60+m};
export const time=(m:number)=>`${Math.floor(m/60).toString().padStart(2,'0')}:${(m%60).toString().padStart(2,'0')}`;
export async function objects(kind:string){const r=await db().prepare('SELECT data FROM objects WHERE kind=?').bind(kind).all();return r.results.map((x:any)=>JSON.parse(x.data))}
export async function catalog(){const overrides=await objects('treatment');return initialTreatments.map(t=>overrides.find(x=>x.id===t.id)||t).concat(overrides.filter(x=>!initialTreatments.some(t=>t.id===x.id)))}
export async function settings(){return {...defaults,...(await objects('settings'))[0]}}
export async function state(){return {treatments:await catalog(),settings:await settings(),therapists:await objects('therapist'),rooms:await objects('room'),blocks:await objects('block')}}
export async function saveObject(kind:string,obj:any){await db().batch([db().prepare('INSERT INTO objects(kind,id,data) VALUES(?,?,?) ON CONFLICT(kind,id) DO UPDATE SET data=excluded.data').bind(kind,String(obj.id),JSON.stringify(obj)),db().prepare('INSERT INTO revision(id,value) VALUES(1,1) ON CONFLICT(id) DO UPDATE SET value=value+1')])}
export async function revisionValue(){return Number((await db().prepare('SELECT value FROM revision WHERE id=1').first<any>())?.value||0)}
export function guard(rev:number){return db().prepare('INSERT INTO guards(key) SELECT 1 WHERE COALESCE((SELECT value FROM revision WHERE id=1),0) != ?').bind(rev)}
export async function allocate(s:any,id:number,date:string,start:number,guests:number,ignore=''){
const t=s.treatments.find((x:any)=>x.id===id);if(!t||!t.active||!t.bookable||!t.minutes)throw Error('Please arrange this treatment with the Ayurveda team.');
if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isInteger(start)||!Number.isInteger(guests)||guests<1||guests>8)throw Error('Invalid appointment details.');
const day=new Date(date+'T12:00:00+05:30').getDay(),hours=s.settings.specialDates?.[date]||s.settings;
const begin=new Date(date+'T'+time(start)+':00+05:30').getTime(),now=Date.now();
if(!Number.isFinite(begin)||begin<now+s.settings.notice*60000||begin>now+s.settings.advance*86400000)throw Error('Please choose a date within the booking window.');
const end=start+t.minutes,until=end+(t.buffer??s.settings.buffer),opening=Math.max(mins(hours.opening),t.opening?mins(t.opening):0),closing=Math.min(mins(hours.closing),t.closing?mins(t.closing):1440);
if(date!==new Date(date+'T12:00:00Z').toISOString().slice(0,10))throw Error('Invalid date');
if(hours.closed||!s.settings.days.includes(day)||!t.days.includes(day)||start<opening||until>closing||(start-opening)%s.settings.interval!==0)throw Error('This time is unavailable.');
if(hours.breakStart&&hours.breakEnd&&start<mins(hours.breakEnd)&&until>mins(hours.breakStart))throw Error('This time is unavailable.');
const booked=await db().prepare("SELECT count(*) as n FROM appointments WHERE date=? AND status!='Cancelled' AND id!=?").bind(date,ignore).first<any>();if(booked.n>=s.settings.maxBookings)throw Error('No more appointments on this date.');
const used=await db().prepare('SELECT DISTINCT resource FROM locks WHERE date=? AND minute>=? AND minute<? AND owner!=?').bind(date,start,until,ignore).all();const busy=new Set(used.results.map((r:any)=>r.resource));
const blocks=s.blocks.filter((b:any)=>b.date===date&&start<b.end&&until>b.start);
if(blocks.some((b:any)=>b.resource==='all'))throw Error('This time is blocked.');
const free=(r:any,kind:string)=>r.active&&!busy.has(kind+':'+r.id)&&!blocks.some((b:any)=>b.resource===kind+':'+r.id)&&!(r.leave||[]).includes(date)&&(!r.opening||start>=mins(r.opening))&&(!r.closing||until<=mins(r.closing));
const therapists=s.therapists.filter((r:any)=>free(r,'therapist')&&r.treatments.includes(id));const rooms=s.rooms.filter((r:any)=>free(r,'room')&&r.type===t.roomType);
if(therapists.length<t.therapists*guests||rooms.length<guests)throw Error('Required therapists or treatment rooms are unavailable.');
return {t,end,until,resources:[...therapists.slice(0,t.therapists*guests).map((x:any)=>'therapist:'+x.id),...rooms.slice(0,guests).map((x:any)=>'room:'+x.id)]};}
export async function slots(id:number,date:string,guests=1,ignore=''){const s=await state();const hours=s.settings.specialDates?.[date]||s.settings;const out:string[]=[];for(let m=mins(hours.opening);m<mins(hours.closing);m+=s.settings.interval){try{await allocate(s,id,date,m,guests,ignore);out.push(time(m))}catch{}}return out}
export async function reserve(body:any,staff=false,existing?:any){
const name=String(body.name||'').trim(),room=String(body.room||'').trim();if(!name||name.length>120||!room||room.length>80)throw Error('Please enter a guest name and room.');
if(String(body.note||'').length>1000||String(body.contact||'').length>80)throw Error('Please shorten the contact or note.');
const rev=await revisionValue();if(existing){const current=await db().prepare('SELECT status FROM appointments WHERE id=?').bind(existing.id).first<any>();if(!current||['Cancelled','Completed'].includes(current.status))throw Error('This appointment can no longer be rescheduled.')}const s=await state(),start=mins(body.time),guests=Number(body.guests),a=await allocate(s,Number(body.treatment),body.date,start,guests,existing?.id);
const id=existing?.id||'CHI-'+crypto.randomUUID().slice(0,8).toUpperCase(),status=existing?'Rescheduled':s.settings.instant?'Confirmed':'Pending';
const data={id,treatment:a.t.id,treatmentName:a.t.name,duration:a.t.duration,minutes:a.t.minutes,price:a.t.price,total:a.t.price===null?null:a.t.price*guests,name,room,guests,contact:String(body.contact||''),note:String(body.note||''),resources:a.resources,date:body.date,time:body.time,start,end:a.end,until:a.until,status,source:staff?'Desk':'Guest'};
const statements=[guard(rev)];if(existing)statements.push(db().prepare('DELETE FROM locks WHERE owner=?').bind(id));
statements.push(db().prepare('INSERT INTO appointments(id,date,start,end,status,data) VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET date=excluded.date,start=excluded.start,end=excluded.end,status=excluded.status,data=excluded.data').bind(id,body.date,start,a.end,status,JSON.stringify(data)));
const lockRows=a.resources.flatMap((resource:string)=>Array.from({length:a.until-start},(_,i)=>({resource,date:body.date,minute:start+i,owner:id})));
statements.push(db().prepare("INSERT INTO locks(resource,date,minute,owner) SELECT json_extract(value,'$.resource'),json_extract(value,'$.date'),json_extract(value,'$.minute'),json_extract(value,'$.owner') FROM json_each(?)").bind(JSON.stringify(lockRows)));
statements.push(db().prepare('INSERT INTO revision(id,value) VALUES(1,1) ON CONFLICT(id) DO UPDATE SET value=value+1'));
try{await db().batch(statements)}catch{throw Error('Availability changed. Please select another available time.')}return data;
}
