// Explicit image assignments: authentic treatments where supplied; preparation imagery otherwise.
// Unmatched eye and spinal photos are not assigned to menu treatments.
export const photography:Record<number,{src:string;alt:string;caption:string}>={
1:{src:'jeevess-oil',alt:'Jeevess therapists applying oil to a guest’s back',caption:'Jeevess · Oil therapy'},
2:{src:'generated-oils',alt:'Brass oil vessel and herbs prepared for a localized oil therapy',caption:'Oil therapy · Preparation'},
3:{src:'generated-room',alt:'Illustrative traditional wooden Ayurveda treatment table',caption:'Kalari oil therapy · Treatment setting'},
4:{src:'unique-kalari-two',alt:'Two brass oil bowls and towels beside a traditional table',caption:"Illustrative preparation / setting"},
5:{src:'generated-scalp',alt:'Scalp-care oil and wooden comb on clean linen',caption:'Head therapy · Preparation'},
6:{src:'jeevess-foot',alt:'Jeevess therapist massaging a guest’s foot with oil',caption:'Jeevess · Foot therapy'},
7:{src:'generated-kalari',alt:'Traditional timber Kalari hall with an earthen floor',caption:'Kalari tradition · Practice setting'},
8:{src:'unique-padaghata',alt:'Support rope above an empty traditional treatment table',caption:"Illustrative preparation / setting"},
9:{src:'generated-facial',alt:'Herbal facial paste in a ceramic bowl with a wooden applicator',caption:'Facial therapy · Preparation'},
10:{src:'jeevess-sirodhara',alt:'Jeevess therapist controlling a fine stream of oil onto a guest’s forehead',caption:'Jeevess · Sirodhara'},
11:{src:'generated-steam',alt:'Traditional wooden full-body steam cabinet in a clean treatment room',caption:'Steam therapy · Treatment setting'},
12:{src:'generated-local-steam',alt:'Localized steam apparatus prepared beside clean linen',caption:'Localized steam · Preparation'},
13:{src:'unique-hair-rinse',alt:'Herbal rinse vessel beside a hair-care basin',caption:"Illustrative preparation / setting"},
14:{src:'generated-mud',alt:'Natural mud preparation in a clay bowl beside white linen in sunlight',caption:'Naturopathy · Mud preparation'},
15:{src:'generated-powders',alt:'Fine herbal powders in clay bowls with cotton muslin',caption:'Herbal powder therapy · Preparation'},
16:{src:'generated-leaves',alt:'Cotton herbal boluses with fresh leaves and a brass bowl',caption:'Herbal leaf therapy · Preparation'},
17:{src:'generated-citrus',alt:'Citrus fruit beside prepared cloth boluses',caption:'Citrus bolus therapy · Preparation'},
18:{src:'generated-rice',alt:'Small-grain rice, cotton boluses and a brass milk bowl',caption:'Rice therapy · Preparation'},
19:{src:'unique-pizhichil',alt:'Wide brass oil vessel and pouring cloth',caption:"Illustrative preparation / setting"},
20:{src:'unique-utsadanam',alt:'Herbal body paste on a ceramic plate with a spatula',caption:"Illustrative preparation / setting"},
21:{src:'generated-bath',alt:'Empty wooden immersion bath prepared with water and clean towels',caption:'Immersion therapy · Treatment setting'},
22:{src:'unique-panchakarma',alt:'Individual Ayurveda care tray with preparation vessels',caption:"Illustrative preparation / setting"},
23:{src:'unique-kalari-training',alt:'Wooden practice staffs in a traditional Kalari hall',caption:"Illustrative preparation / setting"},
24:{src:'generated-yoga',alt:'Quiet yoga pavilion with a mat and soft white curtains',caption:'Yoga · Practice setting'},
25:{src:'generated-consultation',alt:'Quiet consultation desk with a blank notebook and chairs',caption:'Consultation · Care setting'}
};
