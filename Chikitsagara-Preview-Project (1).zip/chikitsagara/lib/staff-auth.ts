import {getChatGPTUser} from '@/app/chatgpt-auth';
import {env} from 'cloudflare:workers';
import {cookies} from 'next/headers';
export async function isStaff(){const user=await getChatGPTUser();const allow=String((env as any).STAFF_EMAILS||'').split(',').map((x:string)=>x.trim().toLowerCase()).filter(Boolean);if(user&&allow.includes(user.email.toLowerCase()))return true;const key=(env as any).PREVIEW_DESK_KEY;return !!key&&(await cookies()).get('preview-desk')?.value===key;}
