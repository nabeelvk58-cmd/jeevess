import {sqliteTable,text,integer,primaryKey} from 'drizzle-orm/sqlite-core';
export const objects=sqliteTable('objects',{kind:text('kind').notNull(),id:text('id').notNull(),data:text('data').notNull()},t=>[primaryKey({columns:[t.kind,t.id]})]);
export const appointments=sqliteTable('appointments',{id:text('id').primaryKey(),date:text('date').notNull(),start:integer('start').notNull(),end:integer('end').notNull(),status:text('status').notNull(),data:text('data').notNull()});
export const locks=sqliteTable('locks',{resource:text('resource').notNull(),date:text('date').notNull(),minute:integer('minute').notNull(),owner:text('owner').notNull()},t=>[primaryKey({columns:[t.resource,t.date,t.minute]})]);
export const revision=sqliteTable('revision',{id:integer('id').primaryKey(),value:integer('value').notNull()});
export const guards=sqliteTable('guards',{key:integer('key').primaryKey()});
